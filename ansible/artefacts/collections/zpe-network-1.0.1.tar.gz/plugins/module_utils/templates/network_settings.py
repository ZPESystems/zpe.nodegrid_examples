def get_template():
    template = """
<group name="network_settings">
hostname = {{ hostname }}
domain_name = {{ domain_name }}
enable_ipv4_ip_forward = {{ enable_ipv4_ip_forward }}
enable_ipv6_ip_forward = {{ enable_ipv6_ip_forward }}
ipv4_loopback = {{ ipv4_loopback }}
ipv6_loopback = {{ ipv6_loopback }}
reverse_path_filtering = {{ reverse_path_filtering }}
enable_multiple_routing_tables = {{ enable_multiple_routing_tables }}
enable_network_failover = {{ enable_network_failover }}
enable_primary_failover_by_ip_address = {{ enable_primary_failover_by_ip_address }}
trigger = {{ trigger }}
enable_primary_failover_by_signal_strength = {{ enable_primary_failover_by_signal_strength }}
enable_primary_failover_by_data_usage = {{ enable_primary_failover_by_data_usage }}
enable_primary_failover_by_schedule = {{ enable_primary_failover_by_schedule }}
enable_primary_sim_failback_by_schedule = {{ enable_primary_sim_failback_by_schedule }}
enable_third_level_network_failover = {{ enable_third_level_network_failover }}
enable_secondary_failover_by_ip_address = {{ enable_secondary_failover_by_ip_address }}
secondary_trigger = {{ secondary_trigger }}
enable_secondary_failover_by_signal_strength = {{ enable_secondary_failover_by_signal_strength }}
enable_secondary_failover_by_data_usage = {{ enable_secondary_failover_by_data_usage }}
enable_secondary_failover_by_schedule = {{ enable_secondary_failover_by_schedule }}
enable_secondary_sim_failback_by_schedule = {{ enable_secondary_sim_failback_by_schedule }}
enable_dynamic_dns = {{ enable_dynamic_dns }}
enable_bluetooth_network = {{ enable_bluetooth_network }}
</group>
"""
    return template