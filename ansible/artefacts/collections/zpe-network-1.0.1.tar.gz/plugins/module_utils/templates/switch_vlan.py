def get_template():
  template = """
<group name="switch_vlans.{{ vlan }}">
  vlan  untagged                                  tagged         {{ _headers_ | columns(3) }}
</group>
"""
  return template