def get_template():
  template = """
<group name="network_statistics.{{ ifname }}">
  {{ ifname | _start_ }}  {{ ifindex }}   {{ state | contains('up','down') }}   {{ rx_packets }}  {{ tx_packets }}  {{ collisions }} {{ dropped }} {{ errors }}
</group>
"""
  return template