# Ansible Collection - zpe.system

Documentation for the collection.

The collection enables users to configure the system features of a Nodegrid appliance.
The collection is designed to be used with Nodegrid version 5.6.1 or higher

