def void(data):
    # function to invalidate results
    return data, False
