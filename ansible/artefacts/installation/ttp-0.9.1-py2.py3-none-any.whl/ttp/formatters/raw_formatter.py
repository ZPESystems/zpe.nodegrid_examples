def raw(data, **kwargs):
    """Method returns parsing results as python list or dictionary."""
    return data
