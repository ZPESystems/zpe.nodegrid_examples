def test(data):
    print("Running input test function, data length {} symbols".format(len(data)))
    return data, None
