def getfilename(data, *args, **kwargs):
    """Return dataname"""
    return args[0]
