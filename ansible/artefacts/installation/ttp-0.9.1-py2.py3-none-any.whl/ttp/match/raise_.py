_name_map_ = {"raise_func": "raise"}


def raise_func(data, message=""):
    raise RuntimeError(message)
