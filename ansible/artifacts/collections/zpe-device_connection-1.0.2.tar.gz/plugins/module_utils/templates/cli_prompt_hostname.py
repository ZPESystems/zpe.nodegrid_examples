def get_template():
    template = """
<group name="hostname">
[admin@{{ hostname | _start_ }} /]#
</group>
"""
    return template