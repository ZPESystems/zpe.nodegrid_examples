def get_template():
    template = """
<group name={{ interface_name}}>
edit {{ interface_name | _line_ | strip() }},
set {{ vdom | _line_ | strip() }},
set ip {{ ipv4_address | _line_ | strip() }} {{ ipv4_subnetmask | _line_ | strip() }}",
set allowaccess {{ allowaccess | _line_ | strip() }},
set type {{ type | _line_ | strip() }},
set role {{ role | _line_ | strip() }}",
set snmp-index {{ index | _line_ | strip() }}",
</group>
"""
    return template