# Ansible Collection - zpe.network

Documentation for the collection.

The collection enables users to configure the network features of a Nodegrid appliance.
The collection is designed to be used with Nodegrid version 5.6.1 or higher

