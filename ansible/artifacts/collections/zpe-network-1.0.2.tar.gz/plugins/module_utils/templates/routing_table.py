def get_template():
  template = """
<group name="routing_table_ipv4.{{ table }}">
  {{ destination | _start_ | contains('.')}}  {{ gateway }}   {{ metric }}  {{ interface }}  {{ from }} {{ table }}
</group>
<group name="routing_table_ipv6.{{ table }}">
  {{ destination | _start_ | contains(':')}}  {{ gateway }}   {{ metric }}  {{ interface }}  {{ from }} {{ table }}
</group>
"""
  return template