def get_template():
  template = """
<group name="network_connections.{{ connection_name }}">
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("up")}} {{ ipv4 | contains('.')}}/{{ ipv4_mask }}  {{ ipv6 | contains(':') }}/{{ ipv6_prefix }} {{ mac }} {{ description}}
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("up")}} {{ ipv4 | contains('.')}}/{{ ipv4_mask }}  {{ ipv6 | contains(':') }}/{{ ipv6_prefix }}    {{ mac }}
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("up")}} {{ ipv6 | contains(':') }}/{{ ipv6_prefix }} {{ mac }} {{ description}}
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("up")}} {{ ipv6 | contains(':') }}/{{ ipv6_prefix }} {{ mac }}
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("up")}} {{ ipv4 | contains('.') }}/{{ ipv4_mask }} {{ mac  }} {{ description}}
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("up")}} {{ ipv4 | contains('.') }}/{{ ipv4_mask }} {{ mac  }}
  {{ connection_name | _start_ }}  {{ status }}   {{ type }}  {{ interface }}  {{ state | equal("down")}} {{ mac }}
</group>
"""
  return template