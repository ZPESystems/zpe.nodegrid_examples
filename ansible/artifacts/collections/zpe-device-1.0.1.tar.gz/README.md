# Ansible Collection - zpe.device

Documentation for the collection.

The collection enables users to connect to managed target devices and to interact with them.
The collection is designed to be used with Nodegrid version 5.6.1 or higher

