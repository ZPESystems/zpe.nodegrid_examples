def get_template():
    template = """
<group name="show_version">
Cisco IOS Software, {{ ignore }} Software ({{ software | _line_ | strip() }}), Version {{ version | _line_ | strip() }}
Copyright (c) 1986-2009 by Cisco Systems, Inc.
Compiled Mon 06-Apr-09 08:19 by amvarma
Image text-base: 0x00003000, data-base: 0x01900000

ROM: Bootstrap program is {{ ignore }} boot loader
BOOTLDR: {{ ignore }} Boot Loader ({{ bootloader | _line_ | strip() }}) Version {{ boot_version | _line_ | strip() }}

{{ hostname | _line_ | strip() }} uptime is {{ uptime_weeks | strip() }} week, {{ uptime_days| strip() }} days, {{ uptime_hours | strip() }} hours, {{ uptime_minutes | strip() }} minutes
System returned to ROM by power-on
System image file is "{{ system_image | _line_ | strip() }}"


This product contains cryptographic features and is subject to United
States and local country laws governing import, export, transfer and
use. Delivery of Cisco cryptographic products does not imply
third-party authority to import, export, distribute or use encryption.
Importers, exporters, distributors and users are responsible for
compliance with U.S. and local country laws. By using this product you
agree to comply with applicable laws and regulations. If you are unable
to comply with U.S. and local laws, return this product immediately.

A summary of U.S. laws governing Cisco cryptographic products may be found at:
http://www.cisco.com/wwl/export/crypto/tool/stqrg.html

If you require further assistance please contact us by sending email to
export@cisco.com.

cisco {{ ignore | _line_ | strip() }} ({{ processor | _line_ | strip() }}) processor (revision {{ processor_revision | _line_ | strip() }}) with {{ memory | _line_ | strip() }} bytes of memory.
Processor board ID {{ processor_board_id | _line_ | strip() }}
Last reset from {{ last_reset | _line_ | strip() }}
{{ virtual_ethernet_interfaces | _line_ | strip() }} Virtual Ethernet interfaces
{{ fast_ethernet_interfaces | _line_ | strip() }} FastEthernet interfaces
{{ gigabit_ethernet_interfaces | _line_ | strip() }} Gigabit Ethernet interfaces
The password-recovery mechanism is {{ password_recovery | _line_ | strip() }}.

{{ configuration_mem | _line_ | strip() }} bytes of flash-simulated non-volatile configuration memory.
Base ethernet MAC Address       : {{ mac_address | _line_ | strip() }}
Motherboard assembly number     : {{ assemblay_number | _line_ | strip() }}
Power supply part number        : {{ power_supply | _line_ | strip() }}
Motherboard serial number       : {{ motherboard_serial_number | _line_ | strip() }}
Power supply serial number      : {{ power_supply_number | _line_ | strip() }}
Model revision number           : {{ model_revision_number | _line_ | strip() }}
Motherboard revision number     : {{ motherboard_revision_number | _line_ | strip() }}
Model number                    : {{ model_number | _line_ | strip() }}
System serial number            : {{ serial_number | _line_ | strip() }}
SFP Module assembly part number : {{ sfp_module_assembly_part_number | _line_ | strip() }}
SFP Module revision Number      : {{ sfp_module_revision_number | _line_ | strip() }}
SFP Module serial number        : {{ sfp_module_serial_number | _line_ | strip() }}
Top Assembly Part Number        : {{ top_assembly_part_number | _line_ | strip() }}
Top Assembly Revision Number    : {{ top_assembly_revision_number | _line_ | strip() }}
Version ID                      : {{ version_id | _line_ | strip() }}
CLEI Code Number                : {{ clei_code_number | _line_ | strip() }}
Hardware Board Revision Number  : {{ hardware_board_revision_number | _line_ | strip() }}
</group>
"""
    return template