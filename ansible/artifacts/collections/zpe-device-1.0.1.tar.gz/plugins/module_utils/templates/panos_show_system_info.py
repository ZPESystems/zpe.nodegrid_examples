def get_template():
    template = """
<group name="show_system_info">
hostname: {{ hostname | _line_ | strip() }}
ip-address: {{ ipv4_address | _line_ | strip() }}
netmask: {{ ipv4_netmask | _line_ | strip() }}
default-gateway: {{ ipv4_default_gateway | _line_ | strip() }}
ip-assignment: {{ ip_assignment | _line_ | strip() }}
ipv6-address: {{ ipv6_address | _line_ | strip() }}
ipv6-link-local-address: {{ ipv6_link_local_address | _line_ | strip() }}
ipv6-default-gateway: {{ ipv6_default_gateway | _line_ | strip() }}
mac-address: {{ mac_address | _line_ | strip() }}
time: {{ time | _line_ | strip() }}
uptime: {{ uptime | _line_ | strip() }}
family: {{ family | _line_ | strip() }}
model: {{ model | _line_ | strip() }}
serial: {{ serail | _line_ | strip() }}
sw-version: {{ version | _line_ | strip() }}
global-protect-client-package-version: {{ global_protect_client_package_version | _line_ | strip() }}
app-version: {{ app_version | _line_ | strip() }}
app-release-date: {{ app_release_date | _line_ | strip() }}
av-version: {{ av_version | _line_ | strip() }}
av-release-date: {{ av_release_date | _line_ | strip() }}
threat-version: {{ threat_version | _line_ | strip() }}
threat-release-date: {{ threat_release_date | _line_ | strip() }}
wf-private-version: {{ wf_private_version | _line_ | strip() }}
wf-private-release-date: {{ wf_private_release_date | _line_ | strip() }}
url-db: {{ url_db | _line_ | strip() }}
wildfire-version: {{ wildfire_version | _line_ | strip() }}
wildfire-release-date: {{ wildfire_release_date | _line_ | strip() }}
url-filtering-version: {{ url_filtering_version | _line_ | strip() }}
global-protect-datafile-version: {{ global_protect_datafile_version | _line_ | strip() }}
global-protect-datafile-release-date: {{ global_protect_datafile_release_date | _line_ | strip() }}
logdb-version: {{ logdb_version | _line_ | strip() }}
platform-family: {{ platform_family | _line_ | strip() }}
vpn-disable-mode: {{ vpn_disable_mode | _line_ | strip() }}
multi-vsys: {{ multi_vsys | _line_ | strip() }}
operational-mode: {{ operational_mode | _line_ | strip() }}
</group>
"""
    return template