#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2022, Rene Neumann <rene.neumann@zpesystems.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)

__metaclass__ = type

DOCUMENTATION = r'''
---
'''

EXAMPLES = r'''
'''

RETURN = r'''
'''

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.zpe.device_connection.plugins.module_utils.connection_util import get_module_params
from ansible_collections.zpe.device_connection.plugins.module_utils.connection_util import get_connection_args
from ansible_collections.zpe.device_connection.plugins.module_utils.connection import NodegridDeviceConnection
from ansible.utils.display import Display
import os

# We have to remove the SID from the Environmental settings, to avoid an issue
# were we can not run pexpect.run multiple times
if "DLITF_SID" in os.environ:
    del os.environ["DLITF_SID"]
if "DLITF_SID_ENCRYPT" in os.environ:
    del os.environ["DLITF_SID_ENCRYPT"]
# import logging
display = Display()


def run_module():
    try:
        # define available arguments/parameters a user can pass to the module
        module_args = get_module_params()

        # seed the result dict in the object
        # we primarily care about changed and state
        # changed is if this module effectively modified the target
        # state will include any data that you want your module to pass back
        # for consumption, for example, in a subsequent task
        result = dict(
            changed=False,
            message=''
        )

        # the AnsibleModule object will be our abstraction working with Ansible
        # this includes instantiation, a couple of common attr would be the
        # args/params passed to the execution, as well as if the module
        # supports check mode
        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )
    except Exception as e:
        result['failed'] = True
        result['message'] = "Error: setting up module"
        result['error_details'] = str(e)
        module.exit_json(**result)
    #
    # Nodegrid OS section starts here
    #
    # Lets get the connection details
    try:
        connection_args = get_connection_args(target_type=module.params['target_os'], module=module.params)
        if not connection_args['target_found']:
            result['failed'] = True
            result['target_check'] = connection_args['target_check']
            result['message'] = connection_args['message']
            result['error'] = connection_args['error']
            module.exit_json(**result)
    except Exception as e:
        result['failed'] = True
        result['message'] = "Error: get device information for device type"
        result['error_conn_details'] = str(e)
        module.exit_json(**result)

    try:
        ngconnection = NodegridDeviceConnection(connection_args)
        device_connection, device_connections_status, debug_output = ngconnection.local_get_connection()
    except Exception as e:
        result['failed'] = True
        result['message'] = "Error: opening device connection "
        result['error_details'] = str(e)
        module.exit_json(**result)

    if device_connections_status == 0:
        # First lets setup the connection Init
        cmds_init_debug = list()
        cmds_output = list()
        cmds_close_debug = list()
        if len(connection_args['cmds_init']) > 0 and connection_args['send_cmds_init']:
            for cmd in connection_args['cmds_init']:
                send_cmds_status, debug_action_list = ngconnection.local_send_cmd(device_connection, cmd)
                cmds_init_debug.append(debug_action_list)
        else:
            send_cmds_status = 0
        # if we found a prompt and the connection init was successful
        # on the device then we can start sending commands
        if send_cmds_status in [0]:
            # Then lets send the cmds
            for cmd in connection_args['cmds']:
                send_cmds_status, output = ngconnection.local_send_cmd(device_connection, cmd)
                cmds_output.append(output)
            # Now lets exit from the connection
            if len(connection_args['cmds_close']) > 0 and connection_args['send_cmds_close']:
                for cmd in connection_args['cmds_close']:
                    send_cmds_status, output = ngconnection.local_send_cmd(device_connection, cmd)
                    cmds_close_debug.append(output)
        else:
            result['failed'] = True
            result['message'] = "Error: init of target device, error code : {}".format(send_cmds_status)
            module.exit_json(**result)
        result['cmds_output'] = cmds_output
    else:
        result['failed'] = True
        result['message'] = "Error: Connection to target device failed, error code : {}".format(device_connections_status)
        result['connection_status'] = device_connections_status
        module.exit_json(**result)
    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)
    error = False
    result['changed'] = True
    result['message'] = ''
    if error:
        module.fail_json(msg='Some Error'.format(''), **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
