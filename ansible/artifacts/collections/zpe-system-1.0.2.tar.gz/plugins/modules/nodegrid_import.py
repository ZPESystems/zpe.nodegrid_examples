#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2022, Rene Neumann <rene.neumann@zpesystems.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: connection_facts
author: Rene Neumann (@zpe-rneumann)
'''

EXAMPLES = r'''
'''

RETURN = r'''
# These are examples of possible return values, and in general should use other names for return values.

'''

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.zpe.system.plugins.module_utils.nodegrid_util import get_nodegrid_os_details
from ansible.utils.display import Display

import pexpect
import os
import re

# We have to remove the SID from the Environmental settings, to avoid an issue
# were we can not run pexpect.run multiple times
if "DLITF_SID" in os.environ:
    del os.environ["DLITF_SID"]
if "DLITF_SID_ENCRYPT" in os.environ:
    del os.environ["DLITF_SID_ENCRYPT"]
# import logging
display = Display()

def get_cli():
    cmd_cli = pexpect.spawn('cli', encoding='UTF-8')
    cmd_cli.setwinsize(500, 250)
    cmd_cli.expect_exact('/]# ')
    cmd_cli.sendline('.sessionpageout undefined=no')
    cmd_cli.expect_exact('/]# ')
    return cmd_cli

def close_cli(cmd_cli):
    cmd_cli.sendline('exit')
    cmd_cli.close()

def import_settings(cmd_cli, change_import_settings_list, use_config_start=True):
    if use_config_start:
        cmd_cli.sendline('config_start')
        cmd_cli.expect_exact('/]# ')
    cmd_cli.sendline("import_settings")
    cmd_cli.expect_exact('finish.')
    for item in change_import_settings_list:
        cmd_cli.sendline(item)
    cmd_cli.sendcontrol('d')
    cmd_cli.expect_exact('/]# ')
    output = cmd_cli.before
    if use_config_start:
        cmd_cli.sendline('config_confirm')
        cmd_cli.expect_exact('/]# ')
    output_dict = {}
    import_status_details = []
    import_status = "succeeded"
    for line in output.splitlines():
        if "Result:" in line:
            settings_status = line.strip().split()
            if len(settings_status) == 4:
                import_status_details.append(dict(
                    path=settings_status[1],
                    result=settings_status[3]
                ))
                if settings_status[3] != "succeeded":
                    import_status = "failed"
                    import_status_details.append(settings_status)
            else:
                import_status = "unknown, result parsing error"
    if "Error" in output or "error" in output:
        output_dict["state"] = 'error'
        # output_dict["output_raw"] = output
        output_dict["import_list"] = change_import_settings_list
        output_dict["import_status"] = import_status
        output_dict["import_status_details"] = import_status_details
    else:
        output_dict["state"] = 'success'
        output_dict["import_list"] = change_import_settings_list
        output_dict["import_status"] = import_status
        output_dict["import_status_details"] = import_status_details
    return output_dict


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        cmds=dict(type='list', required=True)
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        message=''
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    #
    # Nodegrid OS section starts here
    #
    # Lets get the current interface status and check if it must be changed

    nodegrid_os = get_nodegrid_os_details()
    if nodegrid_os['software_major'] < '5':
        module.fail_json(msg='Unsupported Nodegrid OS version. recommended 5.6.1 or higher. Current version: ' + nodegrid_os['software'], **result)
    elif nodegrid_os['software_minor'] < '6':
        result['warning'] = 'Not recommended and untested Nodegrid OS version, some features might not work. recommended 5.6.1 or higher. Current version: ' + nodegrid_os['software']

    # run commands and gather output
    cmd_results = list()
    try:
        cmd_cli = get_cli()
        if nodegrid_os['software_major'] >= '5' and nodegrid_os['software_minor'] >= '6':
            cmd_result = import_settings(cmd_cli, module.params['cmds'])
        else:
            cmd_result = import_settings(cmd_cli, module.params['cmds'], False)
        cmd_results.append(cmd_result)
        close_cli(cmd_cli)
        result['error'] = False
        result['cmds_output'] = cmd_results
    except Exception as exc:
        result['error'] = True
        result['message'] = exc

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
