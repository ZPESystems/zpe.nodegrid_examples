# 1. Install the collection
## 1.1 Manually on a Nodegrid:
- Open a shell 
- Create the folder 'collections' with
`mkdir /var/local/file_manager/admin_group/collections`
- Copy the collection to into the folder

In future versions, will we support direct installation via ansible-galaxy commands 

## 1.2 Usage
The collection is designed to apply a full configuration and currently does not support individual configuration changes.
Configurations Options that are not defined will be reset to default values.

The collection supports ansible check_mode, and diff mode. 
In check_mode no changes are performed, but the playbook will indicate if a change would be required
In diff mode, the playbook with displays the performed changes. Both modes can be combined.

The collection enables users to configure the system features of a Nodegrid appliance.
The collection can be used with Nodegrid version 5.6.1 or higher.

- The current implementation supports:
- System Preferences
- Date and Time
- Any Nodegrid CLI commands
- Import Settings

###### 2. Example Playbooks
###### 2.1 Use existing import_settings to configure a Nodegrid
```
- hosts: all
  gather_facts: false
  collections:
    - zpe.system

  tasks:
  - name: Update zpecloud.com details on Nodegrid using import_settings
    zpe.system.nodegrid_import:
       cmds:
        - "/settings/zpe_cloud enable_zpe_cloud=yes"
        - "/settings/zpe_cloud enable_remote_access=yes"
        - "/settings/zpe_cloud enable_file_protection=no"
        - "/settings/zpe_cloud enable_file_encryption=no"
```
###### 2.2 Use existing import_settings file to configure a Nodegrid
```
- name: Import Settings from import_settings file
  hosts: all
  var:
    import_settings_file: /etc/ansible/templates/settings.j2

  tasks:
    - name: Import settings file
      template:
        src: "{{ import_settings_file }}"
        dest: /tmp/import_settings.cli

    - name: import settings
      zpe.system.nodegrid_cmds:
        cmds:
          - cmd: 'import_settings --file /tmp/import_settings.cli'
      register: output

    - name: response
      debug:
        msg:
          - "stdout: {{ output.stdout }}"
          - "stderr: {{ output.stderr }}"
```

###### 2.3 Use CLI to configure or interact with a Nodegrid
```
- hosts: all
  gather_facts: false
  collections:
    - zpe.system

  tasks:
    - name: Get Network Facts from Nodegrid
      zpe.system.nodegrid_cmds:
        cmds:
          - cmd: 'cd /access/PA-3020'
          - cmd: 'outlet_status'
      register: output

    - name: output
      debug:
        var: output
```

###### 2.4 Configure System Preferences
```
- hosts: all
  gather_facts: false
  collections:
    - zpe.system

  tasks:
  - name: Update System Preferences
    zpe.system.preferences:
        show_hostname_on_webui_header: "yes"
        idle_timeout: "3600"
        enable_banner: "yes"
        enable_local_serial_ports_utilization_rate: "yes"
```

###### 2.5 Configure Date and Time
```
- hosts: all
  gather_facts: false
  collections:
    - zpe.system

  tasks:
    - name: Update Date and Time
      zpe.system.date_and_time:
          date_and_time: "network_time_protocol"
          server: "pool.ntp.org"
          zone: "utc"
          enable_date_and_time_synchronization: "no"
      check_mode: yes
      register: output
```


For more samples, review test cases in the collection Roles or review the documentation.

## Read documentation
```
ansible-doc -t module zpe.system.date_and_time
ansible-doc -t module zpe.system.preferences
```